HOW TO COMPILE
==============

REQUIREMENT: References (the bibliography) only appear if you run the
FULL 4-step compile sequence. If you only run pdflatex once or twice,
you will see [?] in place of citation numbers and no references list.

OPTION A — Easiest (Windows)
-----------------------------
Double-click build.bat. Wait for it to finish. Open main.pdf.

OPTION B — Easiest (Mac/Linux)
-------------------------------
Open Terminal in this folder, run:
    ./build.sh
Open main.pdf.

OPTION C — Manual (any OS, command line)
-----------------------------------------
In the folder containing main.tex, run these FOUR commands in order:
    pdflatex main
    bibtex main
    pdflatex main
    pdflatex main
Open main.pdf.

OPTION D — In Overleaf
-----------------------
Just upload everything in this folder and press Recompile.
Overleaf runs the full sequence automatically.

OPTION E — TeXstudio / TeXmaker
--------------------------------
The "Build & View" button might only run pdflatex. Use the menu:
    Tools -> Commands -> BibTeX
After bibtex, run "Build & View" twice more.

WHY 4 STEPS?
-------------
1. pdflatex main      writes main.aux listing what's cited
2. bibtex main        reads main.aux + refs.bib, builds main.bbl
3. pdflatex main      includes main.bbl, but cite numbers are stale
4. pdflatex main      finalizes cite numbers (e.g., [3] points to ref 3)

If you skip bibtex (step 2), main.bbl is empty/missing, so no
references appear in the PDF. This is the #1 source of confusion.
